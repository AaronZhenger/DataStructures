public class FinalCalcMain {
    public static void main(String[] args) {
        new FinalCalcFrame();
    }
}
